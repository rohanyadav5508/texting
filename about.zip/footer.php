<html>
    <head>
        <title>footer</title>
<link href="index.css" rel="stylesheet">
<link rel="stylesheet" href="https://unpkg.com/bootstrap@5.3.3/dist/css/bootstrap.min.css">
        <link href="css/bootstrap-grid.min.css" rel="stylesheet"/>
        <link href="css/bootstrap.min.css" rel="stylesheet"/>
        <script src="js/bootstrap.bundle.min.js"></script>
        <script src="js/bootstrap.min.js"></script>
        <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.6.0/css/all.min.css" integrity="sha512-Kc323vGBEqzTmouAECnVceyQqyqdsSiqLQISBL29aUW4U/M7pSPA/gEUZQqv1cwx4OnYxTxve5UMg5GT6L4JJg==" crossorigin="anonymous" referrerpolicy="no-referrer" />
        <style>
         
            </style>
        </head>
        <body>
        <div class="box15">
                <div class="row">
                    <div class="col-md-3">
                        <h2 class="environs">Environs</h2>
                        <p class="env_p">The environment gives us countless benefits that we can't repay our entire life. 
                            As they are connected with the forest, trees, animals, water, and air. 
                           </p>
                    </div>
                    <div class="col-md-3">
                        <p class="about_us">Links</p>
                        <ul class="navbar-nav">
                            <a href="index.php" class="a_footer"><li class="li_1">home</li></a>
                            <a href="services.php" class="a_footer"><li class="li_1">services</li></a>
                            <a href="causes.php" class="a_footer"> <li class="li_1">causes</li></a>
                            <a href="eventfetch.php" class="a_footer"> <li class="li_1">events</li></a>
                            <a href="news.php" class="a_footer"> <li class="li_1">pages</li></a>
                            <a href="contact.php" class="a_footer"> <li class="li_1">contact</li></a>
                        </ul>
                    </div>
                    <div class="col-md-3">
                        <h2 class="contact">Contact Us</h2>
                       
                        <h5><i class="fa-duotone fa-solid fa-phone phone1"></i><span class="foot_number">+91 909090909</h5></span><br/>
                        <h5><i class="fa-sharp fa-solid fa-envelope email"></i><span class="foot_number">&nbsp;&nbsp;rohan333@gamil.com</h5></span><br/>
                        <h5><i class="fa-solid fa-location-dot location_footer"></i><span class="foot_number">&nbsp;&nbsp;Ajit road,Street No:18.</h5></span>
                    </div>
                    <div class="col-md-3">
                        <h3 class="gallery_last">Gallery</h3>
                        <div class="row">
                            <div class="col"><img src="envir_img/earth.gif" class="earth"/><br/>
                                <img src="envir_img/envir.gif" class="earth1"/>
                            </div>
                            <div class="col">
                                <img src="envir_img/trees.gif" class="trees"/><br/>
                                <img src="envir_img/earth2.gif" class="earth2"/>
                               
                        </div>
                    </div>
                </div>
            </div>
            </div>
        </body>
</html>        



