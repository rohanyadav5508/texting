<?php
include "header.php";
?>
 
<div class="container mt-3">
  <div class="alert alert-success">
    
    <strong>Success!</strong> Payment Paid Successfully.
  </div>
</div>
 <?php
 include "footer.php";
 ?>