<?php
include "header.php";
?>
    <div class="container-fluid">
                <div class="row">
                <div class="col-md-12">
                    <div class="about_img">
                     <h1 class="about_env">Services</h1>
                        <h5 class="help_us">help today because tomorrow you may be the one who needs more helpings
                        </h5>
                        <div class=" ol_about d-flex">
                      <a href="index.php" class="home_about"><span>Home</span></a>
                      <a href="services.php" class="pages_about"><span>services</span></a>
                        <a href="gallery.php" class="about_about"><span >Gallery</span></a>
                        </div>
                     
                </div>  
                </div>
            </div> 
  <div class="container-fluid box2" >
           <p class="do1"data-aos="fade-up"
           data-aos-duration="3000">WHAT WE DO</p>
           <h3 class="protect2"  data-aos="fade-down"
     data-aos-easing="linear"
     data-aos-duration="1500"> What we do to protect environment
        </h3>
        <br/><br/>
        <div class="container-fluid d-lfex">
            <div class="row">
          
                <div class="col-md-3">
                    <div class="card p5"  data-aos="fade-down" style="width:270px;height:300px;">
               
                   <p class="services_P">Raising Money For Help</p>

                   
                   </div>
                   <div class="lorem5">Define your goal. Start by determining how much money you need to raise. Water is a finite Help Victims of Delhi Riots - Free Crowdfunding For India #1
                 
</div>
                </div>

                <div class="col-md-3">
                    <div class="card p6" data-aos="fade-down" style="width:270px;height:300px;">
                    
                    <p class="services_P">Close Work With <br/>
                    Service</p>
</div>
                    <div class="lorem6">Next to air, water is the most important element for the preservation of life.Fix leaks around your home.
                    Invest in high-efficiency appliances. water-saving showerheads.</div>
                  
</div>
                <div class="col-md-3">
                   <div class="card p7" data-aos="fade-down" style="width:270px;height:300px;">
                    <p class="services_P">Pro Guided Tour<br/>
                    Only</p>
</div>
                    <div class="lorem7">Every household generates waste or garbage. Now, waste  only in trash bins.In the United States, the primary system for controlling waste is the use of these ‘sanitary’ landfills,</div>
                </div>
                    
                <div class="col-md-3 ">
                   <div class="card p8"data-aos="fade-down" style="width:270px;height:300px;"> 
                        <p class="services_end"> Protecting Animal<br/> Area</p>
</div>
                    <div class="lorem8">o study and retrieve all wildlife data, in particular, the amount and development of wildlife.Wildlife is integral to the world’s ecosystems, providing balance and stability to nature’s processes. 
                        
                    </div>


                </div>
                
                </div>
                <button class=" read_more">Read More</button>
            </div>
        </div>

        <script src="https://unpkg.com/aos@2.3.1/dist/aos.js"></script>

<script>
AOS.init();
</script>
<?php
include "footer.php";
?>